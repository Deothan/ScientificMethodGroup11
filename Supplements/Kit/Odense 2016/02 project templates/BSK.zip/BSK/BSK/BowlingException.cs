﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SDU.Assignments.BSK
{
    [Serializable]
    class BowlingException : Exception
    {
        ///TODO: to be implemented
    }
}
