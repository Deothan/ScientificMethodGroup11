﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SDU.Assignments.BSK
{
    public class BowlingGame
    {
        private List<Frame> _frames = new List<Frame>();
        private Frame _bonus;

        public BowlingGame()
        { }

        public void AddFrame(Frame frame)
        {
            ///TODO: to be implemented
        }

        public void SetBonus(int firstThrow, int secondThrow)
        {
            ///TODO: to be implemented
        }

        public int Score
        {
            get
            {
                ///TODO: to be implemented
                return 0;
            }
        }
    }
}
