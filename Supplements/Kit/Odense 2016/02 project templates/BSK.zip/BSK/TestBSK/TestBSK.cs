﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

using SDU.Assignments.BSK;

namespace SDU.Assignments.TestBSK
{
    [TestClass]
    public class TestBSK
    {
        [TestMethod]
        public void TestMethod1()
        {
            Assert.Fail("Not yet implemented...");
        }
    }
}
